package com.tabian.firebasegooglesignin;

public class Const {
	public static final String URL_SEND = "http://10.202.22.213:8080/cuwallet-api/api/service/wallet/send/money/";
	public static final String URL_GET = "http://10.202.22.213:8080/cuwallet-api/api/service/wallet/money/get";
	public static final String URL_ADD = "http://10.202.22.213:8080/cuwallet-api/api/service/wallet/add/money";
	public static final String PROTOCOL = "PROTOCOL_JSON";

	public static final int REQUEST_CLIENT_CODE = 0;
	public static final int REQUEST_TOKEN = 1;
}
